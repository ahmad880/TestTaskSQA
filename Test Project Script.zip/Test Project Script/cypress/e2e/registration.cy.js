/// <reference types= "Cypress" />

import { registration1 } from "../fixtures/PageObject/PageAction/registration";


const registration = new registration1

describe('Volopa',function(){
    beforeEach(()=>{
        cy.visit('https://magento.softwaretestingboard.com/')
        cy.wait(3000)
        // registration.clearCache()
    })
    it('Verify that a user can successfully register with all valid inputs.',()=>{
        registration.valiadtesignup()
    })
    it('Verify that an error message is displayed if both passwords are not same',()=>{
        registration.valiadteErrorMessage()
    })
    it('Verify that if the user does not fill all required fields, it should display error message',()=>{
        registration.valiadterequiredFields()
    })
    

})