/// <reference types= "Cypress" />
const signup= require('../PageElement/registration.json')
export class registration1{
    valiadtesignup(){
        cy.get(signup.registration.signup).click()
        //cy.get(signup.registration.heading).should('have.text','Create New Customer Account')
        cy.get(signup.registration.firstName).type('AAhmad')
        cy.get(signup.registration.lastName).type('AAwais')
        cy.get(signup.registration.email).type('randomemailTesting+1@gmail.com')
        cy.get(signup.registration.password).type('password123#')
        cy.get(signup.registration.confirmPassword).type('password123#')
        cy.get(signup.registration.confirmButton).click()
        cy.get(signup.registration.welcome).should('be.visible')
    }
    valiadteErrorMessage(){
        cy.get(signup.registration.signup).click()
        //cy.get(signup.registration.heading).should('have.text','Create New Customer Account')
        cy.get(signup.registration.firstName).type('AAhmadd')
        cy.get(signup.registration.lastName).type('AAwaiss')
        cy.get(signup.registration.email).type('randomemailTesting123@gmail.com')
        cy.get(signup.registration.password).type('password123#')
        cy.get(signup.registration.confirmPassword).type('password1234')
        cy.get(signup.registration.confirmButton).click()
        cy.get(signup.registration.errormessage).should('contain.text','Please enter the same value again.')
        
    }

    valiadterequiredFields(){
        cy.get(signup.registration.signup).click()
        //cy.get(signup.registration.heading).should('have.text','Create New Customer Account')
        cy.get(signup.registration.firstName).type('AAhmad')
        cy.get(signup.registration.lastName).type('AAwais')
        cy.get(signup.registration.password).type('password123#')
        cy.get(signup.registration.confirmPassword).type('password1234')
        cy.get(signup.registration.confirmButton).click()
        cy.get(signup.registration.errormessage).should('contain.text','Please enter the same value again.')
        cy.get(signup.registration.errormessagefield).should('contain.text','This is a required field.')
        
    }
}